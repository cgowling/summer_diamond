/* This external JavaScript file contains the text blocks */
var externalArray = ["Fist Image – it is the first element of the JavaScript array ‘element’",
                     "Second Image – its index in the array is 1",
                     "Third Image -  its index in the array is 2",
                     "Fourth Image - its index in the array is 3"];
